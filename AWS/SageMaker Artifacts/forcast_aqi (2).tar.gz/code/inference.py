import torch
import json
import numpy as np
from torch.autograd import Variable

def model_fn(model_dir):
    model = torch.jit.load(r'/opt/ml/model/aqi_forecasting.pt')
    return model

def input_fn(request_body, request_content_type):
    request_body = json.loads(request_body)
    input = np.array([request_body['todays_aqi']])
    input = (input - 134.40633) / 91.92531
    x_input = Variable(torch.Tensor(input)).unsqueeze(0).unsqueeze(0)
    return x_input

def predict_fn(input_data, model):
    return model(input_data)

def output_fn(prediction, content_type):
    prediction = prediction.item() * 91.924634 + 134.407155
    prediction = int(prediction)
    return json.dumps({'aqi_forcast': prediction})
