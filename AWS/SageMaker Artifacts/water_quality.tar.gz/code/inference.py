import numpy as np
import torch
import json
from torch.autograd import Variable

def model_fn(model_dir):
    model = torch.jit.load(r'/opt/ml/model/water_quality.pt')
    return model


def input_fn(request_body, request_content_type):
    request_body = json.loads(request_body)
    input = [request_body['pH'], request_body['TDS'], request_body['turbidity']]
    return np.array([input])


def predict_fn(input_data, model):
    input_mean = 7341.713369
    input_std = 2923.64851
    output_mean = 0.390110
    output_std = 0.487849

    def standardize(x):
        return (x - input_mean) / input_std

    def destandardize(y):
        return y * output_std + output_mean
    
    x_standardized = standardize(input_data)
    x_input = Variable(torch.Tensor(x_standardized)).unsqueeze(0)
    x_out = model(x_input)
    x_out_non_standardized = destandardize(x_out.item())
    return 1 if x_out_non_standardized >= 0.45 else 0
    

def output_fn(prediction, content_type):
    return json.dumps({"isGood": prediction})
